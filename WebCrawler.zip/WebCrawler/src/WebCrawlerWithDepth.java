import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


public class WebCrawlerWithDepth {

    private static final int MAX_DEPTH = 3;
    private HashSet<String> links;
    public ArrayList SavedLinks;

    public WebCrawlerWithDepth() {
    	links = new HashSet<>();
    	SavedLinks =  new ArrayList<>();
    }


    public void getPageLinks(String URL, int depth) {
        if ((!links.contains(URL) && (URL != "" ) && (depth < MAX_DEPTH))) {
            System.out.println("Depth: " + depth + " [" + URL + "]");
            SavedLinks.add(URL);
            try {
            	
                links.add(URL);
                
                Document document = Jsoup.connect(URL).get();
                Elements linksOnPage = document.select("a[href]");

                depth++;
                for (Element page : linksOnPage) {
                    getPageLinks(page.attr("abs:href"), depth);
                }

            } catch (IOException e) {
                System.err.println("For '" + URL + "': " + e.getMessage());
            }
        }
    }
    
    
    public void writeToFile(String filename) {
        FileWriter writer;
        
        try {
            writer = new FileWriter(filename);
            
            System.out.println("Writting URLS to " + filename + " ");
            for(int i=0; i<SavedLinks.size(); i++) {
                try {
           
                    String Urls = "URL: " + SavedLinks.get(i) + " \n";
                    //save to file
                    writer.write(Urls);
                    writer.write("\n");
                    
                } catch (IOException e) {
                    System.err.println(e.getMessage());
                }
            }
            writer.close();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
    
    
    

    public static void main(String[] args) {
    	ReadConfig configuration =  new ReadConfig();
    	WebCrawlerWithDepth Crawler = new WebCrawlerWithDepth();
    	Map propertyVals = new HashMap();
    	propertyVals = configuration.executeFileLoader("Crawler.properties");
    	
    	String URL = propertyVals.get("URL").toString();
    	int Depth = Integer.parseInt(propertyVals.get("Depth").toString());
    	
    	Crawler.getPageLinks( URL, Depth );
    	Crawler.writeToFile("CrawledURLS.txt"); 	
    }
}
